import logging
import time
import re
import datetime
from bs4 import BeautifulSoup

from src.selenium_config import SeleniumConfig
from src.base import DarkPost
from src.base import BaseCrawler
from src.mongo import MongoDBClient
from config import GECKO_DRIVER_PATH, BINARY_PATH, PROFILE_PATH, MONGO_HOST, MONGO_PORT, MONGO_USER, MONGO_PASS

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] [%(levelname)s] %(message)s')


class DarkwebCrawler(BaseCrawler):
    base_url = "http://suprbaydvdcaynfo4dgdzgxb4zuso7rftlil5yg5kqjefnw4wq4ulcad.onion"

    def __init__(self):
        super().__init__()
        self.mongodb_client = MongoDBClient(
            host=MONGO_HOST,
            port=MONGO_PORT,
            username=MONGO_USER,
            password=MONGO_PASS
        )

    def init_driver(self):
        driver_config = SeleniumConfig(GECKO_DRIVER_PATH, BINARY_PATH, PROFILE_PATH)
        driver = driver_config.create_firefox_driver()
        driver.implicitly_wait(15)
        return driver


    # ------ Utility methods for parsing the web page ------
    
    def _get_body_html(self):
        bbad_body = self.driver.find_element_by_tag_name("body").get_attribute("innerHTML")
        return BeautifulSoup(bbad_body, 'html.parser')

    def _get_thread_topic(self, soup):
        return soup.find('span', {"class": "active"})

    def _get_thread_section(self, soup):
        navget = soup.find('div', class_= re.compile(r"navigation"))
        listthread = []
        for lh in navget.find_all('a'):

            listthread.append(lh.text)
        # return listthread
        return listthread

    def _get_posts(self, soup):
        # parent_container = soup.find('ul', class_='conversation-list')
        parent_container = soup.find('table', class_='tfixed').find_all('div', class_='post classic')
        # print("ini postt>>>>>>>",parent_container)
        return parent_container

    def _get_last_page_number(self, soup):
        try:
            # Cari semua div dengan class yang mengandung 'pagination'
            pagination_divs = soup.find_all("div", class_=lambda x: x and 'pagination' in x)
            
            # Filter untuk mendapatkan div yang hanya memiliki class 'pagination' saja
            parent_container = None
            for div in pagination_divs:
                classes = div.get('class', [])
                if classes == ['pagination']:  # Memastikan hanya 'pagination' saja
                    parent_container = div
                    break
            
            if not parent_container:
                logging.warning("Pagination container not found")
                return 0

            # Coba dapatkan total dari span.pages
            try:
                get_total = parent_container.find('span', class_="pages").text
                match = re.search(r'\((\d+)\)', get_total)
                if match:
                    return int(match.group(1))
            except Exception as e:
                logging.debug(f"Could not find total in span.pages: {e}")

            # Jika tidak berhasil, coba dari pagination_last
            try:
                last_page = parent_container.find("a", class_="pagination_last").text
                return int(last_page)
            except Exception as e:
                logging.debug(f"Could not find pagination_last: {e}")

            # Jika semua cara gagal
            logging.warning("Could not find total pages")
            return 0

        except Exception as e:
            logging.error(f"Error in get_total_pages: {e}")
            return 0
    
    def _is_op(self, soup):
        return soup.find('a', class_='b-post__count js-show-post-link')
    
    # ------ Utility methods for saving the data ------

    def _save_post(self, data):
        query = {"post_id": data.post_id}
        self.mongodb_client.upsert_document('darkweb', data.__dict__, query)

    # ------ Main methods to scrape the content ------

    def _scrape_post(self, post):
        try:
            poster = post.find('span', class_='largetext').text
            # print("ini poster", poster)

            # if not poster:
            #     poster = post.find('span', {"class": "post-name"})
            div_post_head = post.find('div', class_='post_head')

            # Mencari <a> di dalam div_post_head dan mendapatkan teksnya
            data = div_post_head.find('a').text

            # Mengambil angka dari teks '#1'
            number = int(data.strip('#'))  # Menghapus karakter '#' dan mengonversi ke integer
            if number == 1:
                is_op = True
            else:
                is_op = False
            
            pub_str = post.find('span', class_='post_date')
            time = pub_str if pub_str else None
            # print("ini tanggal", time.text)
            try:
                published_at = datetime.datetime.strptime(
                    time.text, '%b %d, %Y, %I:%M %p'
                )
            except:
                published_at = datetime.datetime.now()
            
            post_content = post.find('div', class_="post_body scaleimages").text
            # print("ini post content", post_content)

            thread_topic = self._get_thread_topic(self._get_body_html())
            # print("ini topik", thread_topic)
            
            thread_section = self._get_thread_section(self._get_body_html())
            # print("ini section", thread_section)
            
            section_rapi = thread_section[:3]
            # print("ini section rapi", section_rapi)

            def clean_content(content):
                # Remove extra newlines
                content = re.sub(r'\n+', ' ', content)
                
                # Remove HTML tags
                content = re.sub(r'<[^>]+>', '', content)
                
                # Remove extra whitespaces
                content = re.sub(r'\s+', ' ', content).strip()
                
                return content
            
            return DarkPost(
                website=self.base_url,
                thread_url=self.driver.current_url,
                thread_topic=thread_topic.text,
                thread_section=section_rapi,
                poster=poster,
                published_at=published_at,
                content=clean_content(post_content),
                raw_content=str(post),
                post_media=None,
                post_id=self.driver.current_url,
                is_op=is_op
            )

        except Exception as e:
            logging.error(f"Error while scraping post: {e}")
            return None

    def scrape(self, url):
        self.driver.get(self.base_url)
        time.sleep(10)
        self.driver.get(url)
        time.sleep(15)

        soup = self._get_body_html()
        last_page = self._get_last_page_number(soup)
        logging.info(f"total page: {last_page}")
        total = 0


        for page in range(int(last_page)):
            page_url = url + f'?page={page + 1}'
            logging.info(f'Navigating to page: {page_url}')

            self.driver.get(page_url)
            time.sleep(15)

            posts = self._get_posts(self._get_body_html())
            
            logging.info(f" posts: {len(posts)}")

            for post in posts:
                data = self._scrape_post(post)
                if data:
                    logging.info(f"Saving post: {data.post_id}")
                    self._save_post(data)
                    logging.info(f"data: {data}")

                    total += 1
                    logging.info(f"Total posts: {total}")

        logging.info(f'Total posts scraped: {total}')
        return total

    def run(self, url):
        print("Post")
        logging.info(f"Starting the scraper for {url}")
        time.sleep(5)
        total = self.scrape(url)
        logging.info(f"Scraping finished for {url}!")
        return total
