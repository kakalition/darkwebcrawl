import logging
import re
import time
import traceback

from bs4 import BeautifulSoup
from config import (
    BINARY_PATH,
    GECKO_DRIVER_PATH,
    MONGO_HOST,
    MONGO_PASS,
    MONGO_PORT,
    MONGO_USER,
    PROFILE_PATH,
)
from src.base import BaseCrawler, DarkProfile
from src.mongo import MongoDBClient
from src.selenium_config import SeleniumConfig
from utils import fill_date_profile

logging.basicConfig(
    level=logging.INFO, format="[%(asctime)s] [%(levelname)s] %(message)s"
)


class DarkwebCrawler(BaseCrawler):
    base_url = "http://suprbaydvdcaynfo4dgdzgxb4zuso7rftlil5yg5kqjefnw4wq4ulcad.onion"

    def __init__(self):
        super().__init__()
        self.mongodb_client = MongoDBClient(
            host=MONGO_HOST, port=MONGO_PORT, username=MONGO_USER, password=MONGO_PASS
        )

    def init_driver(self):
        driver_config = SeleniumConfig(GECKO_DRIVER_PATH, BINARY_PATH, PROFILE_PATH)
        driver = driver_config.create_firefox_driver()
        driver.implicitly_wait(15)
        return driver

    # ------ Utility methods for parsing the web page ------

    def _get_body_html(self):
        bbad_body = self.driver.find_element_by_tag_name("body").get_attribute(
            "innerHTML"
        )
        return BeautifulSoup(bbad_body, "html.parser")

    def _get_member_header(self, soup):
        return soup.find("div", {"class": "memberHeader-content"})

    def _get_member_username(self, soup):
        return soup.find("span", class_="largetext")

    def _get_member_detail(self, soup):
        user_detail = soup.find("div", class_="post_author scaleimages")
        # detail = soup.find_all("div", {"class": "memberHeader-blurb"})
        user_title = user_detail.find("span", {"class": "largetext"}).find("a")
        date_joined = "-"
       # Find the text containing 'Last Active:'
        last_active_text = soup.find("div", "author_statistics").text.split("<br>")[0]

        # Extract the date following "Last Active:"
        if last_active_text:
            last_active = last_active_text.split(':')[1].replace("Threads", "").strip()
        else:
            last_active = "-"
            
        user_title = re.sub(r'\s+', '', user_title.text) if user_title else ""
        last_seen = re.sub(r'\s+', '', last_active) if last_active else ""
        return user_title, date_joined, last_seen

    def _get_member_stats(self, soup):
        author_statistic = soup.find("div", "author_statistics").text.split("<br>")
        otherinfo = soup.find("div", "author_statistics").text
        messages = "-"
        reaction_score = "-"
        points = "-"
        
        stats = re.sub(r'\s+', ' ', otherinfo) if otherinfo else ""
        return messages, reaction_score, points, stats

    # def _get_followers_following(self, soup):
    #     followers_el = None
    #     following_el = None
    #     try:
    #         followers_el = self.driver.find_elements_by_xpath(
    #             "//span[@class='block-footer-counter' \
    #                 and contains(text(), 'follower')]")
    #         following_el = self.driver.find_elements_by_xpath(
    #             "//span[@class='block-footer-counter' \
    #                 and contains(text(), 'following')]")
    #     except Exception as e:
    #         logging.error(f"Error while scraping followers/following: {e}")
    #         followers_el = 0
    #         following_el = 0

    #     followers = 0 if len(followers_el) == 0 else followers_el[0].text \
    #         .replace(" followers", "").replace("Total: ", "")
    #     following = 0 if len(following_el) == 0 else following_el[0].text \
    #         .replace(" following", "").replace("Total: ", "")
    #     return followers, following

    def _get_avatars(self, soup):
        avatar_div = soup.find("div", {"class": "author_avatar"})
        if avatar_div is None:
            return ""  
        avatar_link = avatar_div.find("a")
        if avatar_link is None:
            return ""  
        img_tag = avatar_link.find("img")['src']
        return img_tag
    
    # ------ Utility methods for saving the data ------
    def _get_last_page_number(self, soup):
        last_page = soup.find_all('a', class_='pagination_last')[-1].text
        print("ini llast pagee>>>>>>>>", int(last_page.strip()))
        return int(last_page.strip())
    
    def _get_posts(self, soup):
        return soup.find_all('div', class_='post classic')
    
    def _save_post(self, data):
        query = {"website": data.website, "username": data.username}

        data_dict = fill_date_profile(
            data.__dict__, data.username, data.website, self.mongodb_client)

        self.mongodb_client.upsert_document('darkweb_profiles', data_dict, query)

    def _get_distinct_usernames(self, data):
        query = {"thread_url": data['thread_url']}

        docs = self.mongodb_client.find_document('darkweb', query, 'poster')
        distinct_docs = list(docs)

        profile_urls = []
        for doc in distinct_docs:
            raw_content = self.mongodb_client.find_one(
                'darkweb', {'poster': doc}, {'raw_content': 1, '_id': 0})
            raw_content_bs = BeautifulSoup(raw_content['raw_content'], "html.parser")
            profile = raw_content_bs.find("div", class_="author_information")
            profile_url = profile.find("span", class_="largetext")
            profile_urls.append(profile_url.find('a')["href"])

        return profile_urls

    # ------ Main methods to scrape the content ------

    def _scrape_post(self, post):
        try:
            username_extract = self._get_member_username(post)
            username = username_extract.find("a").text
            user_title, date_joined, last_seen = self._get_member_detail(post)
            messages, reaction_score, points, stats = self._get_member_stats(post)
            print(self._get_member_stats(post))
        

            # followers, following = self._get_followers_following(post)
            img_tag = self._get_avatars(post)
            print(self._get_avatars(post))

            return DarkProfile(
                website=self.base_url+"/"+username,
                username=username,
                user_title=user_title,
                date_joined=date_joined,
                last_seen=last_seen,
                messages=messages,
                reaction_score=reaction_score,
                points=points,
                followers="",
                following="",
                avatar=img_tag,
                additional="",
            )

        except Exception as e:
            logging.error(f"Error while scraping post: {traceback.format_exc()}")
            logging.error(f"Error while scraping post: {e}")
            return None

    def scrape(self, url):
        self.driver.get(url)
        time.sleep(10)

        # usernames = self._get_distinct_usernames({"thread_url": url})
        soup = self._get_body_html()
        last_page = self._get_last_page_number(soup)
        total = 0


        for page in range(last_page):
            page_url = url + f'?page={page + 1}'
            logging.info(f'Navigating to page: {page_url}')

            self.driver.get(page_url)
            time.sleep(15)

            posts = self._get_posts(self._get_body_html())
            for post in posts:
                data = self._scrape_post(post)
                if data:
                    logging.info(f"Saving post: {data.website, data.username}")
                    self._save_post(data)

        #     user_url = self.base_url + user
        #     logging.info(f"Scraping profile for {user}")
        #     self.driver.get(user_url)
        #     time.sleep(15)
        #     soup = self._get_body_html()
        #     data = self._scrape_post(soup)
        #     if data:
        #         logging.info(f"Saving post: {data.website, data.username}")
        #         self._save_post(data)

    def run(self, url):
        logging.info(f"Starting the scraper for {url}")
        time.sleep(5)
        self.scrape(url)
        logging.info(f"Scraping finished for {url}!")
