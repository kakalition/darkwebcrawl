import datetime
import logging
import re
import time

from bs4 import BeautifulSoup
from config import (
    BINARY_PATH,
    GECKO_DRIVER_PATH,
    MONGO_HOST,
    MONGO_PASS,
    MONGO_PORT,
    MONGO_USER,
    PROFILE_PATH,
)
from src.base import BaseCrawler, DarkPost
from src.mongo import MongoDBClient
from src.selenium_config import SeleniumConfig
from utils import clean_html, fill_date

logging.basicConfig(level=logging.INFO, format='[%(asctime)s] [%(levelname)s] %(message)s')


class DarkwebCrawler(BaseCrawler):
    base_url = "https://ezdhgsy2aw7zg54z6dqsutrduhl22moami5zv2zt6urr6vub7gs6wfad.onion"

    def __init__(self):
        super().__init__()
        self.mongodb_client = MongoDBClient(
            host=MONGO_HOST,
            port=MONGO_PORT,
            username=MONGO_USER,
            password=MONGO_PASS
        )

    def init_driver(self):
        driver_config = SeleniumConfig(GECKO_DRIVER_PATH, BINARY_PATH, PROFILE_PATH)
        driver = driver_config.create_firefox_driver()
        driver.implicitly_wait(15)
        return driver


    # ------ Utility methods for parsing the web page ------
    
    def _get_body_html(self):
        bbad_body = self.driver.find_element_by_tag_name("body").get_attribute("innerHTML")
        return BeautifulSoup(bbad_body, 'html.parser')

    def _get_thread_topic(self, soup):
        return soup.find('h1', {"class": "main-title js-main-title hide-on-editmode"})

    def _get_thread_section(self, soup):
        return soup.find('ul', {"id": re.compile(r"breadcrumbs")})

    def _get_posts(self, soup):
        # parent_container = soup.find('ul', class_='conversation-list')
        parent_container = soup.find('ul', class_='conversation-list list-container h-clearfix thread-view')
        # print("ini postt>>>>>>>",parent_container)
        return parent_container

    def _get_last_page_number(self, soup):
        last_page = soup.find('span', class_='pagetotal').text
        print("ini llast pagee>>>>>>>>", int(last_page.strip()))
        return int(last_page.strip())
    
    def _is_op(self, soup):
        return soup.find('a', class_='b-post__count js-show-post-link')
    
    # ------ Utility methods for saving the data ------

    def _save_post(self, data):
        query = {"post_id": data.post_id}
        self.mongodb_client.upsert_document('darkweb', data.__dict__, query)

    # ------ Main methods to scrape the content ------

    def _scrape_post(self, post):
        try:
            poster = post.find('span', itemprop='name').text
            # print("ini poster", poster)

            # if not poster:
            #     poster = post.find('span', {"class": "post-name"})

            is_op = 'b-post--first' in post['class']
            # print("ini is_op", is_op)
            
            pub_str = post.find('time', itemprop='dateCreated')
            time = pub_str['datetime'] if pub_str else None
            # print("ini tanggal", time)
            
            post_content = post.find('div', {"class": "js-post__content-text restore h-wordwrap"}).text
            # print("ini post content", post_content)

            thread_topic = self._get_thread_topic(self._get_body_html())
            # print("ini topik", thread_topic)
            
            thread_section = self._get_thread_section(self._get_body_html())
            # print("ini section", thread_section)
            
            section_rapi = list(filter(None, thread_section.text.split("\n")))
            # print("ini section rapi", section_rapi)

            return DarkPost(
                website=self.base_url,
                thread_url=self.driver.current_url,
                thread_topic=thread_topic.text,
                thread_section=list(filter(None, thread_section.text.split("\n"))),
                poster=poster,
                published_at=time,
                content=post_content,
                raw_content=str(post),
                post_media=None,
                post_id=post.find('a', {"class": "b-post__count js-show-post-link"})['href'],
                is_op=is_op
            )

        except Exception as e:
            logging.error(f"Error while scraping post: {e}")
            return None

    def scrape(self, url):
        self.driver.get(self.base_url)
        time.sleep(10)
        self.driver.get(url)
        time.sleep(15)

        soup = self._get_body_html()
        last_page = self._get_last_page_number(soup)
        total = 0


        for page in range(last_page):
            page_url = url + f'/page{page + 1}'
            logging.info(f'Navigating to page: {page_url}')

            self.driver.get(page_url)
            time.sleep(15)

            posts = self._get_posts(self._get_body_html())
            # print(posts)
            for post in posts:
                data = self._scrape_post(post)
                if data:
                    logging.info(f"Saving post: {data.post_id}")
                    self._save_post(data)
                    logging.info(f"data: {data}")

                    total += 1
                    logging.info(f"Total posts: {total}")

        logging.info(f'Total posts scraped: {total}')
        


    def run(self, url):
        logging.info(f"Starting the scraper for {url}")
        time.sleep(5)
        self.scrape(url)
        logging.info(f"Scraping finished for {url}!")
